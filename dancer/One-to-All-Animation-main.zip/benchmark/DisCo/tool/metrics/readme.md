### requirments

sudo apt-get update
sudo apt-get install ffmpeg
pip install ffmpeg-python