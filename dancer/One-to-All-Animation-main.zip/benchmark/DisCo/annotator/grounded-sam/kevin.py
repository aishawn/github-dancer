import sys
import os
pythonpath = os.path.abspath(
    os.path.dirname(__file__))
print(pythonpath)