# grounded-sam-osx
This is a submodule of [Grounded-SAM](https://github.com/IDEA-Research/Grounded-Segment-Anything). It can estimate full-body pose and shape from a monuculor image. The combined of Grounded-SAM and OSX supports promptable 3D whole-body mesh recovery. 
