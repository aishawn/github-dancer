from config.disco_w_tm.tem_disco_temp_attn import TemConvNet as Net
from config.disco_w_tm.tem_disco_temp_attn import inner_collect_fn
from config.disco_w_tm.yz_tiktok_S256L16_xformers_tsv import Args, args
